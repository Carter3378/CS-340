# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = username
        PASS = password
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
    #***********************************************************************************************#      
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        #validate input data exists
        if data is not None: 
            #insert the document into the collection
            resultInsert = self.database.animals.insert_one(data)  # data should be dictionary 
            
            #check if there was a returned insert id to confirm success
            if resultInsert.inserted_id:
                return True
            else:
                return False
        else: 
            #raise an exception if no data was passed to the insert function
            raise Exception("Nothing to save, the data parameter to insert is empty") 
    #***********************************************************************************************#      
    # Create method to implement the R in CRUD.
    def read(self, query):
        #validate query data exists
        if query is not None:
            #query the animals collection using the criteria provided
            resultQuery = self.database.animals.find(query)
            
            #convert cursor to list before returning
            return list(resultQuery)
        else:
            #raise an exception if no data was passed to the insert function
            raise Exception("Nothing to query, the query parameter to find is empty")
    #***********************************************************************************************#          
    # Create method to implement the U in CRUD.
    def update(self, query, change):
        #validate query data exists
        if query is not None and change is not None:
            #update matching query returns using $set 
            resultUpdate = self.database.animals.update_many(query,{"$set": change})
            
            #return the number of documents that were modified
            return resultUpdate.modified_count
        else:
            #raise an exception if no data was passed to the insert function
            raise Exception("Incompatible query or update data, the qeury/change parametere is empty")
    #***********************************************************************************************#              
    # Create method to implement the D in CRUD.
    def delete(self, remove):
        #validate information to delete exists
        if remove is not None:
            #delete the documents that match
            resultDelete = self.database.animals.delete_many(remove)
            
            #return the number of documents that were deleted from the database
            return resultDelete.deleted_count
        else:
            #raise an exception if no data was passed to the delete function
            raise Exception("Nothing to delete, the remove parameter to delete is empty")